# Priority recheck: maximal sublattices of convex geometries

Rechecked 13 October 2026, 14:14–14:20 UTC, after the release of v1.0.0
(doi:10.5281/zenodo.23343145). The first two checks (11:50–12:00 and 12:40–12:50 UTC the same day)
are in `repository/PRIORITY-CHECK.md`.

| Source | Search | Result |
|---|---|---|
| arXiv API | `all:"maximal sublattice"`, newest first | one hit: arXiv:2507.22682 itself (v3, 21 July 2026) |
| arXiv API | `all:semidistributive`, newest 15 | nothing on maximal sublattices; newest is arXiv:2609.07382 (shellability) |
| arXiv API | `all:"convex geometries"`, newest 15 | nothing on lattices of closed sets or maximal sublattices |
| Crossref | doi:10.46298/dmtcs.16374 (DMTCS 28:2, Combinatorics section, 23 July 2026) | cited by 0 works |
| Semantic Scholar | papers citing arXiv:2507.22682 | none |
| OpenAlex | the DMTCS article | cited by 0 works |
| Zenodo | `"maximal sublattice"`; `semidistributive AND sublattice` | only this deposit (doi:10.5281/zenodo.23343145) |
| Zenodo | the identifier 2507.22682 | no records |
| OpenRefute (the-omega-institute/trureturing) | issues and PRs for `sublattice` | six results, none about maximal sublattices, semidistributive lattices, convex geometries or the paper |
| Web search | the authors with "maximal sublattices", "semidistributive", "counterexample" | only the paper, its arXiv versions, its DMTCS page and talk abstracts by S. Silberger on the convex dimension two case |

Conclusion: as of 14:20 UTC on 13 October 2026 nobody else has refuted Hypotheses 2, 3 or 4 or
answered Question 2. Hypothesis 1, the 1997 question of Adams, Freese, Nation and Schmid, is still
open and is not claimed.
