Deep Bhattacharjee
Formerly, Electro-Gravitational Space Propulsion Laboratory (EGSPL), Bhubaneswar, Odisha, India
d.bhattacharjee@erl-forschung.de · itsdeep@live.com · ORCID 0000-0003-0466-750X

To the Editors, Discrete Mathematics & Theoretical Computer Science (Combinatorics section)

Dear Editors,

I submit the manuscript "Maximal sublattices of convex geometries: four counterexamples" for consideration in the Combinatorics section of DMTCS. The preprint is at arXiv:ARXIV_ID.

In "Conjecture on maximal sublattices of finite semidistributive lattices and beyond" (DMTCS 28:2, 2026, doi:10.46298/dmtcs.16374), Adaricheva, Mata, Silberger and Zamojska-Dzienio put forward four hypotheses and a question on the complement of a maximal sublattice of a finite lattice, and proved them for convex geometries of convex dimension two. The manuscript gives a seventeen-element convex geometry in which such a complement has two minimal elements, refuting their Hypothesis 2 and Hypothesis 4, and a twenty-five-element convex geometry of convex dimension three with the same behaviour, so their theorem for convex dimension two does not extend. The same two examples answer the join half of their Question 2 in the negative, an eleven-element convex geometry answers the meet half, and a ten-element lattice refutes Hypothesis 3. The first hypothesis, the 1997 question of Adams, Freese, Nation and Schmid, is not settled; an exhaustive computation shows that a counterexample has more than fourteen elements.

Every counterexample is proved by hand in the paper and checked in the Lean 4 proof assistant with Mathlib by the kernel alone. The Lean development and all programs are archived at doi:10.5281/zenodo.23343145.

The manuscript is not under consideration elsewhere. There is no funding to report and no competing interest. The use of a generative AI tool is declared in the manuscript.

Yours sincerely,
Deep Bhattacharjee
