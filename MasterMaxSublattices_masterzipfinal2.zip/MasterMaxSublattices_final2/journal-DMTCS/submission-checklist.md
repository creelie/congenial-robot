# DMTCS: submission checklist

Manuscript: "Maximal sublattices of convex geometries: four counterexamples" (Deep Bhattacharjee,
sole author). Target: Discrete Mathematics & Theoretical Computer Science, Combinatorics section,
the section in which Adaricheva, Mata, Silberger and Zamojska-Dzienio published the hypotheses
(DMTCS 28:2, 2026). DMTCS is diamond open access: no fee for authors or readers.

DMTCS is an overlay journal on Episciences. A submission is a public preprint on arXiv (or HAL)
plus a form on https://dmtcs.episciences.org that points to it.

## Steps

1. Post the preprint to arXiv: upload `../preprint/maximal-sublattices-cg-arxiv-final2.tar.gz`;
   primary category math.RA (as the paper of Adaricheva et al.), cross-list math.CO; license
   CC BY 4.0; MSC 06B05 (primary), 06B15, 52A01, 05B35.
2. When arXiv announces it, put the identifier in `cover-letter.md` (ARXIV_ID).
3. On https://dmtcs.episciences.org choose "Submit an article", give the arXiv identifier, choose
   the Combinatorics section, paste the cover letter, and enter the keywords exactly as in the
   manuscript: maximal sublattice, convex geometry, join-semidistributive lattice,
   meet-irreducible element, formal verification.
4. After acceptance, replace the arXiv version by the journal-style source
   `dmtcs-manuscript-source-final2.zip` (it compiles with pdfLaTeX; the class file
   `dmtcs-episciences.cls` of 19 May 2026 is included).

## Files in this folder

| File | Use |
| --- | --- |
| `dmtcs-manuscript-final2.pdf` | The manuscript in the journal's own style (`submission` option) |
| `dmtcs-manuscript-source-final2.zip` | Its LaTeX source, figures and the DMTCS class |
| `cover-letter.md` | Cover letter for the submission form |

## What only the author can confirm

- [ ] No funding: the manuscript states that the research received no specific grant.
- [ ] No competing interests: the manuscript states there are none.
- [ ] The declaration of generative AI use at the end of the manuscript is accurate.
- [ ] The manuscript is not under consideration at another journal.
- [ ] The arXiv posting is made from the author's own arXiv account.

## Already done

- Abstract, keywords, journal class, and a Declarations section (funding, competing interests,
  data availability, use of generative AI).
- The archive is cited by its DOI, doi:10.5281/zenodo.23343145.
- Every reference and DOI checked online.
- The Lean proofs build and the axiom audit passes (twenty theorems, standard axioms only).

Fallback journals, in order: Algebra Universalis; Order.
