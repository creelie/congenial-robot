# Master zip: maximal sublattices of convex geometries (final2)

Built 13 October 2026, 14:20 UTC, from creelie/congenial-robot, main at 8462e1d (release v1.0.0
with its DOI recorded).

- Paper: "Maximal sublattices of convex geometries: four counterexamples", Deep Bhattacharjee
  (sole author).
- DOI of release v1.0.0: [10.5281/zenodo.23343145](https://doi.org/10.5281/zenodo.23343145);
  all versions: [10.5281/zenodo.23343144](https://doi.org/10.5281/zenodo.23343144).
- Target journal: Discrete Mathematics & Theoretical Computer Science, Combinatorics section, where
  the hypotheses were published (DMTCS 28:2, 2026). Diamond open access, no fees. Fallbacks:
  Algebra Universalis; Order.

## What is proved

Adaricheva, Mata, Silberger and Zamojska-Dzienio (DMTCS 28:2, 2026, doi:10.46298/dmtcs.16374)
stated four hypotheses and a question on the complement C of a maximal sublattice of a finite
lattice.

- Hypothesis 2 is false: in a 17-element convex geometry C has two minimal elements, and in a
  25-element convex geometry of convex dimension three it has three, so their theorem for convex
  dimension two does not extend.
- Hypothesis 3 is false (a 10-element lattice).
- Hypothesis 4 is false (the same two convex geometries).
- Question 2 has a negative answer in both halves (the same two geometries, and an 11-element one).

Every example is proved by hand and in Lean 4 with Mathlib, by the kernel alone (no
`native_decide`); twenty theorems use only the standard axioms.

## What is open

- Hypothesis 1, the 1997 question of Adams, Freese, Nation and Schmid: is C always an interval in
  a finite semidistributive lattice? Not claimed. It holds for every lattice with at most fourteen
  elements, so a counterexample is larger.
- The least size of a convex dimension three counterexample to Hypothesis 2 (between 15 and 25).
- Whether C is always order convex in a finite convex geometry.

## Contents

| Path | What it is |
| --- | --- |
| `journal-DMTCS/dmtcs-manuscript-final2.pdf` | Manuscript in the journal's own class (dmtcs-episciences, submission option) |
| `journal-DMTCS/dmtcs-manuscript-source-final2.zip` | Its LaTeX source, figures and the class file |
| `journal-DMTCS/cover-letter.md` | Cover letter |
| `journal-DMTCS/submission-checklist.md` | Submission steps (arXiv first, then Episciences) and what only the author can confirm |
| `preprint/maximal-sublattices-cg-final2.pdf` | The preprint (amsart), as released |
| `preprint/maximal-sublattices-cg-tex-final2.zip` | Its LaTeX source with PNG figures |
| `preprint/maximal-sublattices-cg-arxiv-final2.tar.gz` | The arXiv upload |
| `PRIORITY-RECHECK-2026-10-13.md` | Priority recheck, 14:14–14:20 UTC on 13 October 2026 |
| `repository/` | The repository at 8462e1d: Lean proofs, C and Python checks, data, outputs, scripts and the two earlier priority checks |

## Before submitting

DMTCS needs a public arXiv preprint before the Episciences submission; the arXiv tarball is in
`preprint/`. The manuscript already states no funding and no competing interests; please confirm
both. See `journal-DMTCS/submission-checklist.md`.
